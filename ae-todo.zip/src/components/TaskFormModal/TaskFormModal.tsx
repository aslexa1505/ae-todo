import React, { useState, useCallback, useEffect } from 'react';
import { Modal } from '../Modal/Modal';
import './TaskFormModal.scss';

interface TaskFormModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (
        title: string,
        description: string,
        priority: 'low' | 'medium' | 'high',
        files: string[]
    ) => void;
}

export const TaskFormModal: React.FC<TaskFormModalProps> = ({ isOpen, onClose, onSave }) => {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
    const [files, setFiles] = useState<string[]>([]);

    const handleSubmit = useCallback(
        (e: React.FormEvent) => {
            e.preventDefault();
            onSave(title, description, priority, files);
            setTitle('');
            setDescription('');
            setPriority('medium');
            setFiles([]);
            onClose();
        },
        [title, description, priority, files, onSave, onClose]
    );

    const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const urls = Array.from(e.target.files).map((file) => URL.createObjectURL(file));
            setFiles(urls);
        }
    }, []);

    // При закрытии модального окна сбрасываем состояние формы
    useEffect(() => {
        if (!isOpen) {
            setTitle('');
            setDescription('');
            setPriority('medium');
            setFiles([]);
        }
    }, [isOpen]);

    return (
        <Modal isOpen={isOpen} onClose={onClose}>
            <div className="task-form-modal">
                <h2>Создать задачу</h2>
                <form onSubmit={handleSubmit}>
                    <label>Название задачи:</label>
                    <input
                        type="text"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        required
                    />
                    <label>Описание:</label>
                    <textarea
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        required
                    />
                    <label>Приоритет:</label>
                    <select
                        value={priority}
                        onChange={(e) => setPriority(e.target.value as 'low' | 'medium' | 'high')}
                    >
                        <option value="low">Низкий</option>
                        <option value="medium">Средний</option>
                        <option value="high">Высокий</option>
                    </select>
                    <label>Файлы (изображения):</label>
                    <input type="file" multiple onChange={handleFileChange} />
                    <div className="buttons">
                        <button type="submit">Создать</button>
                        <button type="button" onClick={onClose}>
                            Отмена
                        </button>
                    </div>
                </form>
            </div>
        </Modal>
    );
};
