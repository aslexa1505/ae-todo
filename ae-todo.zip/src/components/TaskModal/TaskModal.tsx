import React, { useState, useEffect, useCallback, useMemo, memo } from 'react';
import { Task as TaskType, Comment } from 'store/types';
import { Modal } from 'components/Modal/Modal';
import './TaskModal.scss';

interface TaskModalProps {
    task: TaskType;
    onClose: () => void;
    onUpdateTask?: (updatedTask: TaskType) => void; // для обновления задачи в Redux/хранилище
    onOpenTask?: (task: TaskType) => void; // для открытия модалки по клику на подзадачу
}

interface CommentItemProps {
    comment: Comment;
    task: TaskType;
    onUpdateTask?: (updatedTask: TaskType) => void;
}

const CommentItem: React.FC<CommentItemProps> = memo(({ comment, task, onUpdateTask }) => {
    const [showReplyForm, setShowReplyForm] = useState(false);
    const [replyText, setReplyText] = useState('');

    const toggleReplyForm = useCallback(() => {
        setShowReplyForm((prev) => !prev);
    }, []);

    const handleAddReply = useCallback(() => {
        if (!replyText.trim() || !onUpdateTask) return;
        const newReply: Comment = {
            id: 'reply-' + Date.now(),
            text: replyText,
            author: 'User',
            createdAt: new Date().toISOString(),
            replies: []
        };

        const updatedReplies = [...(comment.replies ?? []), newReply];
        const updatedComment = { ...comment, replies: updatedReplies };

        // Обновляем список комментариев, заменяя старый комментарий на обновленный
        const updatedComments = (task.comments ?? []).map((c) =>
            c.id === comment.id ? updatedComment : c
        );
        onUpdateTask({ ...task, comments: updatedComments });
        setReplyText('');
        setShowReplyForm(false);
    }, [replyText, comment, task, onUpdateTask]);

    return (
        <li className="comment-item">
            <div className="comment-content">
                <strong>{comment.author}</strong> ({new Date(comment.createdAt).toLocaleString()}):{' '}
                {comment.text}
            </div>
            <button onClick={toggleReplyForm}>Ответить</button>
            {showReplyForm && (
                <div className="reply-form">
                    <textarea
                        placeholder="Ваш ответ"
                        value={replyText}
                        onChange={(e) => setReplyText(e.target.value)}
                    />
                    <button onClick={handleAddReply}>Отправить ответ</button>
                </div>
            )}
            {comment.replies && comment.replies.length > 0 && (
                <ul className="replies">
                    {comment.replies.map((reply) => (
                        <CommentItem
                            key={reply.id}
                            comment={reply}
                            task={task}
                            onUpdateTask={onUpdateTask}
                        />
                    ))}
                </ul>
            )}
        </li>
    );
});

export const TaskModal: React.FC<TaskModalProps> = ({
    task,
    onClose,
    onUpdateTask,
    onOpenTask
}) => {
    // Режим редактирования
    const [isEditing, setIsEditing] = useState(false);

    // Локальные состояния для редактируемых полей
    const [title, setTitle] = useState(task.title);
    const [description, setDescription] = useState(task.description);
    const [workTime, setWorkTime] = useState(task.workTime || '');
    const [finishedAt, setFinishedAt] = useState(task.finishedAt || '');
    const [priority, setPriority] = useState(task.priority);
    const [status, setStatus] = useState(task.status);
    const [files, setFiles] = useState<string[]>(task.files || []);

    // Для добавления подзадачи и комментариев
    const [newSubtaskTitle, setNewSubtaskTitle] = useState('');
    const [newSubtaskDescription, setNewSubtaskDescription] = useState('');
    const [newCommentText, setNewCommentText] = useState('');

    // При изменении задачи обновляем локальные состояния
    useEffect(() => {
        setTitle(task.title);
        setDescription(task.description);
        setWorkTime(task.workTime || '');
        setFinishedAt(task.finishedAt || '');
        setPriority(task.priority);
        setStatus(task.status);
        setFiles(task.files || []);
    }, [task]);

    // Сохранение изменений основной задачи
    const handleSaveChanges = useCallback(() => {
        const updatedTask: TaskType = {
            ...task,
            title,
            description,
            workTime,
            finishedAt,
            priority,
            status,
            files
        };
        onUpdateTask && onUpdateTask(updatedTask);
        setIsEditing(false);
    }, [task, title, description, workTime, finishedAt, priority, status, files, onUpdateTask]);

    // Добавление подзадачи
    const handleAddSubtask = useCallback(() => {
        if (!newSubtaskTitle.trim() || !onUpdateTask) return;
        const newSubtask: TaskType = {
            id: 'sub-' + Date.now(),
            number: (task.subtasks?.length ?? 0) + 1,
            title: newSubtaskTitle,
            description: newSubtaskDescription,
            createdAt: new Date().toISOString(),
            workTime: '',
            finishedAt: '',
            priority: 'medium',
            status: task.status,
            subtasks: [],
            comments: [],
            files: []
        };
        const updatedTask: TaskType = {
            ...task,
            subtasks: [...(task.subtasks ?? []), newSubtask]
        };
        onUpdateTask(updatedTask);
        setNewSubtaskTitle('');
        setNewSubtaskDescription('');
    }, [newSubtaskTitle, newSubtaskDescription, task, onUpdateTask]);

    // Добавление комментария
    const handleAddComment = useCallback(() => {
        if (!newCommentText.trim() || !onUpdateTask) return;
        const newComment: Comment = {
            id: 'comm-' + Date.now(),
            text: newCommentText,
            author: 'User',
            createdAt: new Date().toISOString(),
            replies: []
        };
        const updatedTask: TaskType = {
            ...task,
            comments: [...(task.comments ?? []), newComment]
        };
        onUpdateTask(updatedTask);
        setNewCommentText('');
    }, [newCommentText, task, onUpdateTask]);

    // Мемоизация отрисовки списка подзадач
    const renderedSubtasks = useMemo(() => {
        return (task.subtasks?.length ?? 0) > 0 ? (
            task.subtasks!.map((subtask) => (
                <li
                    key={subtask.id}
                    onClick={() => onOpenTask && onOpenTask(subtask)}
                    className="subtask-item"
                >
                    #{subtask.number} {subtask.title}
                </li>
            ))
        ) : (
            <li>Нет подзадач</li>
        );
    }, [task.subtasks, onOpenTask]);

    const renderedComments = useMemo(() => {
        return (task.comments?.length ?? 0) > 0 ? (
            task.comments!.map((comment) => (
                <CommentItem
                    key={comment.id}
                    comment={comment}
                    task={task}
                    onUpdateTask={onUpdateTask}
                />
            ))
        ) : (
            <li>Нет комментариев</li>
        );
    }, [task.comments, task, onUpdateTask]);

    return (
        <Modal isOpen={true} onClose={onClose}>
            <div className="task-modal">
                <div className="modal-header">
                    <h2>Детали задачи #{task.number}</h2>
                    <div className="header-actions">
                        {isEditing ? (
                            <button className="save-btn" onClick={handleSaveChanges}>
                                Сохранить изменения
                            </button>
                        ) : (
                            <button className="edit-btn" onClick={() => setIsEditing(true)}>
                                Редактировать
                            </button>
                        )}
                    </div>
                </div>
                <div className="modal-content">
                    {/* Основная информация */}
                    <section className="section-details">
                        {isEditing ? (
                            <>
                                <label>Заголовок:</label>
                                <input value={title} onChange={(e) => setTitle(e.target.value)} />
                                <label>Описание:</label>
                                <textarea
                                    value={description}
                                    onChange={(e) => setDescription(e.target.value)}
                                />
                                <label>Приоритет:</label>
                                <select
                                    value={priority}
                                    onChange={(e) =>
                                        setPriority(e.target.value as 'low' | 'medium' | 'high')
                                    }
                                >
                                    <option value="low">Низкий</option>
                                    <option value="medium">Средний</option>
                                    <option value="high">Высокий</option>
                                </select>
                                <label>Статус:</label>
                                <select
                                    value={status}
                                    onChange={(e) =>
                                        setStatus(
                                            e.target.value as 'Queue' | 'Development' | 'Done'
                                        )
                                    }
                                >
                                    <option value="Queue">Queue</option>
                                    <option value="Development">Development</option>
                                    <option value="Done">Done</option>
                                </select>
                            </>
                        ) : (
                            <>
                                <p>
                                    <strong>Заголовок:</strong> {title}
                                </p>
                                <p>
                                    <strong>Описание:</strong> {description}
                                </p>
                                <p>
                                    <strong>Приоритет:</strong> {priority}
                                </p>
                                <p>
                                    <strong>Статус:</strong> {status}
                                </p>
                                <p>
                                    <strong>Дата создания:</strong>{' '}
                                    {new Date(task.createdAt).toLocaleString()}
                                </p>
                            </>
                        )}
                    </section>
                    {/* Подзадачи */}
                    <section className="section-subtasks">
                        <h3>Подзадачи</h3>
                        <ul>{renderedSubtasks}</ul>
                        {isEditing && (
                            <div className="add-subtask">
                                <input
                                    type="text"
                                    placeholder="Название подзадачи"
                                    value={newSubtaskTitle}
                                    onChange={(e) => setNewSubtaskTitle(e.target.value)}
                                />
                                <textarea
                                    placeholder="Описание подзадачи"
                                    value={newSubtaskDescription}
                                    onChange={(e) => setNewSubtaskDescription(e.target.value)}
                                />
                                <button onClick={handleAddSubtask}>Добавить подзадачу</button>
                            </div>
                        )}
                    </section>
                    {/* Комментарии */}
                    <section className="section-comments">
                        <h3>Комментарии</h3>
                        <ul>{renderedComments}</ul>
                        <div className="add-comment">
                            <textarea
                                placeholder="Ваш комментарий"
                                value={newCommentText}
                                onChange={(e) => setNewCommentText(e.target.value)}
                            />
                            <button onClick={handleAddComment}>Добавить комментарий</button>
                        </div>
                    </section>
                </div>
            </div>
        </Modal>
    );
};
